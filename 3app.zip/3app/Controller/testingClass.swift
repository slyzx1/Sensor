//
//  testingClass.swift
//  3app
//
//  Created by 肖政铎 on 2020/2/20.
//  Copyright © 2020年 肖政铎. All rights reserved.
//

import UIKit

class testingClass: NSObject {

}
